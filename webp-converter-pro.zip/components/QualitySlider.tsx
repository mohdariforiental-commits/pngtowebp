import React from 'react';

interface QualitySliderProps {
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
}

const QualitySlider: React.FC<QualitySliderProps> = ({ value, onChange, disabled }) => {
  const percentage = Math.round(value * 100);
  
  // Determine color based on quality for visual feedback
  const getColor = () => {
    if (percentage < 50) return 'text-orange-500';
    if (percentage < 80) return 'text-indigo-500';
    return 'text-green-500';
  };

  return (
    <div className="w-full bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="flex justify-between items-center mb-4">
        <label htmlFor="quality-slider" className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
          Quality
        </label>
        <span className={`text-lg font-bold font-mono ${getColor()}`}>
          {percentage}%
        </span>
      </div>
      
      <input
        id="quality-slider"
        type="range"
        min="0"
        max="1"
        step="0.01"
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        disabled={disabled}
        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 hover:accent-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
      />
      
      <div className="flex justify-between mt-2 text-xs text-gray-400">
        <span>Low Size</span>
        <span>Balanced</span>
        <span>High Detail</span>
      </div>
    </div>
  );
};

export default QualitySlider;
