import React from 'react';

interface AdSensePlaceholderProps {
  slotId?: string;
  className?: string;
}

const AdSensePlaceholder: React.FC<AdSensePlaceholderProps> = ({ slotId = "1234567890", className }) => {
  return (
    <div className={`w-full bg-gray-100 border border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 p-4 ${className}`}>
        <span className="text-xs font-semibold tracking-wider uppercase mb-2">Advertisement</span>
        <div className="w-full h-24 bg-gray-200 rounded animate-pulse flex items-center justify-center">
             <span className="text-xs text-gray-500">Google AdSense Space</span>
        </div>
        {/* 
          To integrate AdSense:
          1. Add the AdSense script tag in index.html <head>.
          2. Replace this component's content with your <ins> tag.
          
          Example:
          <ins className="adsbygoogle"
               style={{ display: 'block' }}
               data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
               data-ad-slot={slotId}
               data-ad-format="auto"
               data-full-width-responsive="true"></ins>
          <script>
               (adsbygoogle = window.adsbygoogle || []).push({});
          </script>
        */}
    </div>
  );
};

export default AdSensePlaceholder;
