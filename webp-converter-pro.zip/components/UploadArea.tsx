import React, { useCallback, useState } from 'react';
import { UploadIcon } from './Icons';

interface UploadAreaProps {
  onFileSelect: (file: File) => void;
  error?: string | null;
}

const UploadArea: React.FC<UploadAreaProps> = ({ onFileSelect, error }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const files = e.dataTransfer.files;
      if (files && files.length > 0) {
        validateAndPassFile(files[0]);
      }
    },
    [onFileSelect]
  );

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      validateAndPassFile(e.target.files[0]);
    }
  };

  const validateAndPassFile = (file: File) => {
    if (file.type === 'image/png' || file.type === 'image/jpeg' || file.type === 'image/jpg') {
      onFileSelect(file);
    } else {
      alert('Only PNG and JPG files are supported currently.');
    }
  };

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`
        relative w-full cursor-pointer rounded-xl border-2 border-dashed transition-all duration-300 ease-in-out
        flex flex-col items-center justify-center p-10
        ${
          isDragging
            ? 'border-indigo-500 bg-indigo-50/50 scale-[1.01]'
            : 'border-gray-300 bg-white hover:border-gray-400 hover:bg-gray-50'
        }
        ${error ? 'border-red-400 bg-red-50' : ''}
      `}
    >
      <input
        type="file"
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        onChange={handleInputChange}
        accept="image/png, image/jpeg"
      />
      <div className="flex flex-col items-center space-y-4 text-center">
        <div className={`p-4 rounded-full ${isDragging ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-500'}`}>
          <UploadIcon className="w-8 h-8" />
        </div>
        <div>
          <p className="text-lg font-semibold text-gray-700">
            {isDragging ? 'Drop image here' : 'Click or Drag image here'}
          </p>
          <p className="text-sm text-gray-500 mt-1">
            Supports PNG and JPG
          </p>
        </div>
      </div>
    </div>
  );
};

export default UploadArea;
