export interface ProcessedImage {
  url: string;
  name: string;
  size: number;
  width: number;
  height: number;
  type: string;
}

export interface ConversionResult {
  blob: Blob;
  url: string;
  size: number;
}

export interface ConversionOptions {
  quality: number; // 0 to 1
}
