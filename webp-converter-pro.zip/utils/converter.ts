import { ProcessedImage, ConversionResult } from '../types';

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const loadImage = (file: File): Promise<ProcessedImage> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        resolve({
          url: img.src,
          name: file.name.split('.')[0], // Remove extension
          size: file.size,
          width: img.width,
          height: img.height,
          type: file.type,
        });
      };
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
};

export const convertToWebP = (
  imageUrl: string,
  quality: number
): Promise<ConversionResult> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas context not available'));
        return;
      }
      // Draw white background for transparent PNGs if needed, 
      // but WebP supports transparency, so we keep it clear usually.
      // If conversion from transparent PNG -> WebP, it keeps transparency.
      ctx.drawImage(img, 0, 0);

      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve({
              blob,
              url: URL.createObjectURL(blob),
              size: blob.size,
            });
          } else {
            reject(new Error('Conversion failed'));
          }
        },
        'image/webp',
        quality
      );
    };
    img.onerror = () => reject(new Error('Error loading image for conversion'));
    img.src = imageUrl;
  });
};
