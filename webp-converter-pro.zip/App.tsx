import React, { useState, useEffect, useCallback } from 'react';
import { ProcessedImage, ConversionResult } from './types';
import { loadImage, convertToWebP, formatFileSize } from './utils/converter';
import UploadArea from './components/UploadArea';
import QualitySlider from './components/QualitySlider';
import AdSensePlaceholder from './components/AdSensePlaceholder';
import { DownloadIcon, RefreshIcon, XIcon } from './components/Icons';

function App() {
  const [originalImage, setOriginalImage] = useState<ProcessedImage | null>(null);
  const [convertedResult, setConvertedResult] = useState<ConversionResult | null>(null);
  const [quality, setQuality] = useState<number>(0.8);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Debounce conversion to avoid lagging while dragging slider
  useEffect(() => {
    if (!originalImage) return;

    const timer = setTimeout(() => {
      handleConversion(originalImage, quality);
    }, 150); // Small delay for smooth UI

    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quality, originalImage]);

  const handleConversion = async (image: ProcessedImage, q: number) => {
    setIsProcessing(true);
    setError(null);
    try {
      const result = await convertToWebP(image.url, q);
      setConvertedResult(result);
    } catch (err) {
      console.error(err);
      setError('Failed to convert image. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileSelect = async (file: File) => {
    setError(null);
    setIsProcessing(true);
    try {
      const processed = await loadImage(file);
      setOriginalImage(processed);
      // Reset quality to default on new file
      setQuality(0.8);
      // Trigger initial conversion
      await handleConversion(processed, 0.8);
    } catch (err) {
      console.error(err);
      setError('Could not load image. Please try another file.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReset = () => {
    if (convertedResult?.url) {
      URL.revokeObjectURL(convertedResult.url);
    }
    setOriginalImage(null);
    setConvertedResult(null);
    setError(null);
    setQuality(0.8);
  };

  const handleDownload = () => {
    if (!convertedResult || !originalImage) return;
    
    const link = document.createElement('a');
    link.href = convertedResult.url;
    link.download = `${originalImage.name}.webp`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Calculate size savings
  const savings =
    originalImage && convertedResult
      ? Math.round(
          ((originalImage.size - convertedResult.size) / originalImage.size) * 100
        )
      : 0;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">
              W
            </div>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">
              WebP<span className="text-indigo-600">Converter</span>
            </h1>
          </div>
          <a 
            href="https://github.com" 
            target="_blank" 
            rel="noreferrer"
            className="text-sm font-medium text-gray-500 hover:text-indigo-600 transition-colors"
          >
            About
          </a>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        {/* Main Title Section */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <h2 className="text-4xl font-extrabold text-gray-900 sm:text-5xl tracking-tight">
            Convert Images to WebP
          </h2>
          <p className="text-lg text-gray-500">
            Make your website faster by converting PNG and JPG images to modern WebP format.
            100% client-side, secure, and free.
          </p>
        </div>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {/* Left Column: Upload & Controls */}
          <div className="lg:col-span-1 space-y-6">
            {!originalImage ? (
              <div className="bg-white p-2 rounded-2xl shadow-sm border border-gray-100">
                <UploadArea onFileSelect={handleFileSelect} error={error} />
              </div>
            ) : (
              <div className="space-y-6">
                <QualitySlider 
                  value={quality} 
                  onChange={setQuality} 
                  disabled={isProcessing} 
                />
                
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 space-y-4">
                  <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">
                    File Details
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Original Size:</span>
                      <span className="font-medium text-gray-900">{formatFileSize(originalImage.size)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Dimensions:</span>
                      <span className="font-medium text-gray-900">{originalImage.width} x {originalImage.height}</span>
                    </div>
                  </div>
                  <button
                    onClick={handleReset}
                    className="w-full flex items-center justify-center space-x-2 px-4 py-2 border border-gray-200 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                  >
                    <XIcon className="w-4 h-4" />
                    <span>Remove Image</span>
                  </button>
                </div>
              </div>
            )}
             {/* Ad Space Mobile/Desktop Stack */}
             <AdSensePlaceholder className="min-h-[250px]" />
          </div>

          {/* Right Column: Previews */}
          <div className="lg:col-span-2 space-y-6">
            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                {error}
              </div>
            )}

            {!originalImage ? (
              // Empty State
              <div className="h-96 rounded-2xl border-2 border-dashed border-gray-200 bg-gray-50 flex flex-col items-center justify-center text-gray-400">
                <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mb-4">
                  <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <p>Preview will appear here</p>
              </div>
            ) : (
              <div className="space-y-6">
                 {/* Comparison Card */}
                 <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
                    {/* Header of Card */}
                    <div className="p-4 bg-gray-50 border-b border-gray-100 flex justify-between items-center">
                       <h3 className="font-bold text-gray-800">Conversion Preview</h3>
                       {savings > 0 && (
                         <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Saved {savings}%
                         </span>
                       )}
                    </div>

                    {/* Image Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-gray-100">
                       {/* Original */}
                       <div className="p-6 space-y-3">
                          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider text-center">Original ({originalImage.type.split('/')[1].toUpperCase()})</p>
                          <div className="relative aspect-square rounded-lg bg-[url('https://bg.site/checker.png')] bg-gray-100 overflow-hidden flex items-center justify-center group">
                             <div className="absolute inset-0 pattern-grid opacity-10 pointer-events-none"></div>
                             <img 
                               src={originalImage.url} 
                               alt="Original" 
                               className="max-w-full max-h-full object-contain shadow-sm"
                             />
                          </div>
                          <p className="text-center font-mono text-sm text-gray-600">
                            {formatFileSize(originalImage.size)}
                          </p>
                       </div>

                       {/* Converted */}
                       <div className="p-6 space-y-3 bg-indigo-50/10">
                          <p className="text-xs font-semibold text-indigo-500 uppercase tracking-wider text-center">WebP Result</p>
                          <div className="relative aspect-square rounded-lg bg-gray-100 overflow-hidden flex items-center justify-center">
                             {isProcessing ? (
                                <div className="absolute inset-0 flex items-center justify-center bg-white/80 z-10">
                                   <RefreshIcon className="w-8 h-8 text-indigo-600 animate-spin" />
                                </div>
                             ) : null}
                             <div className="absolute inset-0 pattern-grid opacity-10 pointer-events-none"></div>
                             {convertedResult && (
                               <img 
                                 src={convertedResult.url} 
                                 alt="Converted" 
                                 className="max-w-full max-h-full object-contain shadow-sm"
                               />
                             )}
                          </div>
                          <p className="text-center font-mono text-sm font-bold text-indigo-700">
                             {convertedResult ? formatFileSize(convertedResult.size) : '...'}
                          </p>
                       </div>
                    </div>

                    {/* Action Bar */}
                    <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end">
                       <button
                         onClick={handleDownload}
                         disabled={!convertedResult || isProcessing}
                         className="flex items-center space-x-2 px-8 py-3 bg-indigo-600 text-white rounded-xl font-semibold shadow-lg shadow-indigo-200 hover:bg-indigo-700 hover:shadow-indigo-300 disabled:opacity-50 disabled:shadow-none transition-all transform hover:-translate-y-0.5 active:translate-y-0"
                       >
                         {isProcessing ? (
                           <RefreshIcon className="w-5 h-5 animate-spin" />
                         ) : (
                           <DownloadIcon className="w-5 h-5" />
                         )}
                         <span>Download WebP</span>
                       </button>
                    </div>
                 </div>
              </div>
            )}
          </div>
        </div>

        {/* Feature Section (SEO-lite) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-10 border-t border-gray-200">
          <div className="p-6 bg-white rounded-xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-900 mb-2">Private & Secure</h3>
            <p className="text-gray-500 text-sm">All conversions happen locally in your browser. Your images never leave your device.</p>
          </div>
          <div className="p-6 bg-white rounded-xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-900 mb-2">Lightning Fast</h3>
            <p className="text-gray-500 text-sm">Powered by modern browser technology for instant conversion without server latency.</p>
          </div>
          <div className="p-6 bg-white rounded-xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-900 mb-2">High Quality</h3>
            <p className="text-gray-500 text-sm">Advanced compression keeps your images looking crisp while reducing file size significantly.</p>
          </div>
        </div>

        <footer className="text-center text-gray-400 text-sm py-8">
          &copy; {new Date().getFullYear()} WebP Converter Pro. All rights reserved.
        </footer>
      </main>
      
      {/* Hidden pattern for transparency background */}
      <style>{`
        .pattern-grid {
          background-image: linear-gradient(45deg, #000 25%, transparent 25%), linear-gradient(-45deg, #000 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #000 75%), linear-gradient(-45deg, transparent 75%, #000 75%);
          background-size: 20px 20px;
          background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
        }
      `}</style>
    </div>
  );
}

export default App;
